package server;

public interface Log {
	public void log(String string);
}
