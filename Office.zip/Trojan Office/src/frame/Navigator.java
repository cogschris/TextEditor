package frame;

public interface Navigator {
	public void toMain();
	public void toLogin();
	public void toSignup();
}
