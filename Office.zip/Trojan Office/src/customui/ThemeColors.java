package customui;

import java.awt.Color;

public class ThemeColors {
	public static final Color MainColor = new Color(230, 106, 25, 200);
	public static final Color SecondColor = new Color(110, 110, 0, 100);
	public static final Color WhiteColor = Color.WHITE;
}
